interface CheckButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  variant?: 'filled' | 'outlined'
}

function CheckButton({
  children,
  size = 'md',
  variant = 'filled',
  ...props
}: CheckButtonProps): React.JSX.Element {
  return (
    <button
      {...props}
      className={`${size === 'lg' ? 'w-full' : size === 'md' ? 'w-1/2' : size === 'sm' && 'w-1/3'}  ${variant === 'filled' ? 'border-btn-sky bg-btn-sky flex items-center justify-center py-2.5 text-white' : 'border-btn-sky bg-white flex items-center justify-center py-2.5 text-btn-sky'} rounded-xl border-2`}
    >
      {children}
    </button>
  )
}

export { CheckButton }
