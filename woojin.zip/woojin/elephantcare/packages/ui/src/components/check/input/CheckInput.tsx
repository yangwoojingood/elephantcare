interface CheckInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  placeholder: string
  variant?: 'filled' | 'outlined'
}
function CheckInput({
  placeholder,
  variant = 'outlined',
  ...props
}: CheckInputProps):React.JSX.Element {
  return (
    <input
      type='text'
      placeholder={placeholder}
      className={`w-full text-lg font-bold ${variant === 'filled' ? 'border-btn-sky bg-white flex items-center justify-center text-btn-sky' : 'border-bordergrey border-2 rounded-lg pl-4 bg-white flex items-center justify-center'} py-3 text-deactivate placeholder:text-deactivate`}
      {...props}
    />
  )
}

export { CheckInput }
