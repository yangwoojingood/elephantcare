import { SupabaseClient } from '@supabase/supabase-js'

/**
 * @param table 테이블 이름
 * @param insertData 삽입할 데이터
 * @returns 삽입된 데이터
 */
const insertDataToTable = async <T>(
  supabase: SupabaseClient,
  table: string,
  insertData: T
): Promise<T> => {
  const { data, error } = await supabase.from(table).insert(insertData)
  if (error) {
    throw error
  }
  return data as T
}

export { insertDataToTable }
