import { SupabaseClient } from '@supabase/supabase-js'

/**
 * @param table 테이블 이름
 * @returns 테이블 데이터
 */
const selectDataFromTable = async <T>(
  supabase: SupabaseClient,
  table: string
): Promise<T> => {
  const { data, error } = await supabase.from(table).select('*')
  if (error) {
    throw error
  }
  return data as T
}

/**
 * @param row 조회할 컬럼
 * @param table 테이블 이름
 * @param column 조회할 컬럼
 * @param id 조회할 아이디
 * @returns 조회된 데이터
 */
interface SelectDataProps {
  supabase: SupabaseClient
  row?: string
  table: string
  column: string
  id: string
}
const selectData = async <T>({
  supabase,
  row = '*',
  table,
  column,
  id
}: SelectDataProps): Promise<T> => {
  const { data, error } = await supabase
    .from(table)
    .select(row)
    .eq(column, id)
    .single()
  if (error) {
    throw error
  }
  return data as T
}

interface SelectDataWithOrderProps extends SelectDataProps {
  order_row: string
}
const selectDataWithOrder = async <T>({
  supabase,
  row = '*',
  table,
  column,
  id,
  order_row = 'order_num'
}: SelectDataWithOrderProps): Promise<T> => {
  const { data, error } = await supabase
    .from(table)
    .select(row)
    .eq(column, id)
    .order(order_row, { ascending: true })

  return data as T
}

export { selectDataFromTable, selectData, selectDataWithOrder }
