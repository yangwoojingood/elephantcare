import { SupabaseClient } from '@supabase/supabase-js'

/**
 * @param table 테이블 이름
 * @param target 삭제할 데이터의 속성
 * @param id 삭제할 데이터의 아이디
 * @returns 삭제된 데이터
 */
const deleteDataFromTable = async (
  supabase: SupabaseClient,
  table: string,
  target: string,
  id: string
) => {
  const { data, error } = await supabase.from(table).delete().eq(target, id)
  if (error) {
    throw error
  }
  return data
}

export { deleteDataFromTable }
