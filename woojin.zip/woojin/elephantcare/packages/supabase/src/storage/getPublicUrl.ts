import { SupabaseClient } from '@supabase/supabase-js'

/**
 * @param storageName 스토리지 이름
 * @param imgPath 이미지 이름
 * @returns 이미지 주소
 */
const getImageUrl = async (
  supabase: SupabaseClient,
  storageName: string,
  imgPath: string
): Promise<string> => {
  const { data } = await supabase.storage
    .from(storageName)
    .getPublicUrl(`${imgPath}`)

  return data.publicUrl
}

export { getImageUrl }
