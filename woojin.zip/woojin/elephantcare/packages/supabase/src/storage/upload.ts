import { SupabaseClient } from '@supabase/supabase-js'

const getNewFileName = (file: File): string => {
  const parts = file.name.split('.')
  const extension = parts.pop() // 확장자 추출
  const baseName = parts.join('.') // 파일명 추출
  return `${baseName}${Date.now()}.${extension}`
}

const uploadImage = async (
  supabase: SupabaseClient,
  image: File
): Promise<string> => {
  const newFileName = getNewFileName(image)
  const { data, error } = await supabase.storage
    .from('programs')
    .upload(`thumbnail/${newFileName}`, image)
  if (error) {
    throw error
  }
  return data.path
}

const uploadFile = async (
  supabase: SupabaseClient,
  bucket: string,
  syllabusFile: File
): Promise<string> => {
  const newFileName = getNewFileName(syllabusFile)
  const { data, error } = await supabase.storage
    .from('programs')
    .upload(`${bucket}/${newFileName}`, syllabusFile)
  if (error) {
    throw error
  }
  return data.path
}

export { uploadImage, uploadFile }
