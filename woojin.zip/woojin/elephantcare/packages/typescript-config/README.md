# `@packages/typescript-config`

Shared typescript configuration for the packages.
