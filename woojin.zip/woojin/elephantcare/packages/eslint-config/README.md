# `@packages/eslint-config`

Shared eslint configuration for the packages.
