export * from '../../packages/ui/tailwind.config'
