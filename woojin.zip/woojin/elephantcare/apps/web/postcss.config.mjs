export { default } from '@packages/ui/postcss.config'
