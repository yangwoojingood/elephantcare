import { create } from 'zustand'

import { supabase } from '@packages/supabase/utils/client'

interface AuthState {
  isAuth: boolean
  loading: boolean
  checkAuth: () => Promise<void>
  setIsAuth: (isAuth: boolean) => void
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuth: false,
  loading: true,
  setIsAuth: (isAuth) => set({ isAuth }),
  checkAuth: async () => {
    try {
      const {
        data: { user }
      } = await supabase.auth.getUser()
      set({ isAuth: !!user })
    } catch (error) {
      set({ isAuth: false })
    } finally {
      set({ loading: false })
    }
  }
}))
