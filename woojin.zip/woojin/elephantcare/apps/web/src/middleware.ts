import { type CookieOptions, createServerClient } from '@supabase/ssr'
import { type NextRequest, NextResponse } from 'next/server'

// 공개 경로 상수 정의
const PUBLIC_PATHS = ['/auth', '/force-logout', '/programs', '/api/auth']

export async function middleware(req: NextRequest) {
  if (
    req.nextUrl.pathname === '/' ||
    PUBLIC_PATHS.some((publicPath) =>
      req.nextUrl.pathname.startsWith(publicPath)
    )
  ) {
    return NextResponse.next({
      request: { headers: req.headers }
    })
  }
  const res = NextResponse.next()

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return req.cookies.get(name)?.value
        },
        set(name: string, value: string, options: CookieOptions) {
          res.cookies.set({ name, value, ...options })
        },
        remove(name: string, options: CookieOptions) {
          res.cookies.set({ name, value: '', ...options })
        }
      }
    }
  )

  const {
    data: { session }
  } = await supabase.auth.getSession()
  // 비로그인 사용자 처리
  if (!session) {
    return NextResponse.redirect(new URL('/auth', req.url))
  }

  const { data } = await supabase
    .from('user_session')
    .select('token')
    .eq('user_id', session.user.id)
    .single()
  if (data?.token !== session.refresh_token) {
    supabase.auth.signOut()
    return NextResponse.redirect(new URL('/force-logout', req.url))
  }

  // classes 경로 권한 체크
  if (req.nextUrl.pathname.startsWith('/classes')) {
    const requiredPermission = req.nextUrl.pathname.split('/')[2]
    const { data } = await supabase
      .from('User')
      .select('id')
      .eq('email', session.user.email)
      .contains('permissions', [requiredPermission])
      .single()

    if (!data) {
      const redirectUrl = new URL('/no-permission', req.url)
      redirectUrl.searchParams.set('status', '403')
      return NextResponse.redirect(redirectUrl)
    }
  }

  return NextResponse.next({
    request: { headers: req.headers }
  })
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|assets/images|assets/icons).*)'
  ]
}
