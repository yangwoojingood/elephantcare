import { useEffect } from 'react'
import { useState } from 'react'

import { useDebounce } from './useDebounce'

function useSubjectSearch(handleSearchSubject: (search: string) => void) {
  const [search, setSearch] = useState('')

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value)
  }

  const debouncedSearch = useDebounce(search, 500)

  useEffect(() => {
    handleSearchSubject(debouncedSearch)
  }, [debouncedSearch, handleSearchSubject])
  return { search, handleSearch }
}
export { useSubjectSearch }
