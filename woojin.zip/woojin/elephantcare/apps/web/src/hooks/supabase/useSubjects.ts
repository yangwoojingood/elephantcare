import {
  ClassCategoriesType,
  GradeCategoriesType,
  SubjectType
} from '@/types/programs/grade'
import { filterSubject } from '@/utils'
import { useAuthStore } from '@stores'
import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'react-toastify'

import { selectDataFromTable } from '@packages/supabase/database/select'
import { getImageUrl } from '@packages/supabase/storage/getPublicUrl'
import { createClient } from '@packages/supabase/utils/client'

function useSubjects() {
  const { isAuth } = useAuthStore()
  const subjectRef = useRef<SubjectType[]>([])
  const [filteredSubjects, setFilteredSubjects] = useState<SubjectType[]>([])
  const [category, setCategory] = useState<
    GradeCategoriesType | ClassCategoriesType
  >('전체')
  const [isLoading, setIsLoading] = useState(true)

  const handleFilterSubject = useCallback(
    (category: GradeCategoriesType | ClassCategoriesType) => {
      setCategory(category)
      const filtered = filterSubject(subjectRef.current, category)
      setFilteredSubjects(filtered)
    },
    [subjectRef]
  )

  const handleSearchSubject = useCallback(
    (search: string) => {
      const filtered = subjectRef.current.filter((subject) =>
        subject.title.includes(search)
      )
      setFilteredSubjects(filtered)
    },
    [subjectRef]
  )

  useEffect(() => {
    const fetchSubjects = async () => {
      try {
        const supabase = createClient()
        setIsLoading(true)
        const data = await selectDataFromTable<SubjectType[]>(
          supabase,
          'subjects'
        )
        if (data) {
          const subjectsWithImages: SubjectType[] = await Promise.all(
            data.map(async (subject) => ({
              ...subject,
              imageUrl: await getImageUrl(supabase, 'programs', subject.imgSrc)
            }))
          )
          subjectRef.current = subjectsWithImages
          setFilteredSubjects(subjectsWithImages)
        }
      } catch (error) {
        toast.error('데이터를 불러오는데 실패했습니다.')
        console.error('Error fetching subjects:', error)
      } finally {
        setIsLoading(false)
      }
    }
    fetchSubjects()
  }, [isAuth])

  return {
    handleSearchSubject,
    filteredSubjects,
    category,
    setCategory,
    handleFilterSubject,
    isLoading
  }
}

export { useSubjects }
