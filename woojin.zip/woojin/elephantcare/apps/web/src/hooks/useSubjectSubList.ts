import { ClassItemType, SubjectSubType, SubjectType } from '@/types'
import { useEffect, useState } from 'react'

import {
  selectData,
  selectDataWithOrder
} from '@packages/supabase/database/select'
import { getImageUrl } from '@packages/supabase/storage/getPublicUrl'
import { createClient } from '@packages/supabase/utils/client'

export function useSubjectSubList(id: string) {
  const [subjectData, setSubjectData] = useState<SubjectType | null>(null)
  const [subSubjectData, setSubSubjectData] = useState<SubjectSubType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true)
        const supabase = createClient()
        const subjectData = await selectData<SubjectType>({
          supabase,
          row: 'title, syllabus',
          table: 'subjects',
          column: 'id',
          id
        })

        const subSubjectData = await selectDataWithOrder<SubjectSubType[]>({
          supabase,
          row: '*',
          table: 'subject_subcategories',
          column: 'subject_id',
          id,
          order_row: 'order_num'
        })

        subSubjectData.forEach(async (subSubjectItem: SubjectType) => {
          const imageUrl = await getImageUrl(
            supabase,
            'programs',
            subSubjectItem.imgSrc
          )
          subSubjectItem.imageUrl = imageUrl
        })
        setSubjectData(subjectData || null)
        setSubSubjectData(subSubjectData as SubjectSubType[])
      } catch (error) {
        console.error(error)
      } finally {
        setIsLoading(false)
      }
    }
    fetchData()
  }, [id])

  return { subjectData, subSubjectData, isLoading }
}
