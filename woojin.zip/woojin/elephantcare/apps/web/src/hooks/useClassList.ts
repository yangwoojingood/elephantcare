import { ClassItemType, SubjectType } from '@/types'
import { useEffect, useState } from 'react'

import {
  selectData,
  selectDataWithOrder
} from '@packages/supabase/database/select'
import { createClient } from '@packages/supabase/utils/client'

export function useClassList(id: string, subId?: string) {
  const [subjectData, setSubjectData] = useState<SubjectType | null>(null)
  const [classData, setClassData] = useState<ClassItemType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true)
        const supabase = createClient()
        const subjectData = await selectData<SubjectType>({
          supabase,
          row: 'title, syllabus',
          table: subId ? 'subject_subcategories' : 'subjects',
          column: 'id',
          id: subId ? subId : id
        })
        const classData = await selectDataWithOrder<ClassItemType[]>({
          supabase,
          row: '*',
          table: 'classes',
          column: subId ? 'category_id' : 'subject_id',
          id: subId ? subId : id,
          order_row: 'order_num'
        })
        setSubjectData(subjectData || null)
        setClassData(classData)
      } catch (error) {
        console.error(error)
      } finally {
        setIsLoading(false)
      }
    }
    fetchData()
  }, [id, subId])

  return { subjectData, classData, isLoading }
}
