interface OverlayConfig {
  pageNumber: number
  content: React.ReactNode
  position?: 'top' | 'middle' | 'bottom'
}
export type { OverlayConfig }
