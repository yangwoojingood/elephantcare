type imageSizeType = { width: number; height: number }
interface MainButtonType {
  id: string
  title: string[]
  href: string
  bgColor: string
  ringColor: string
  image: string
  imageSize: imageSizeType
  className: string
  imagePosition: string
}

export type { MainButtonType }
