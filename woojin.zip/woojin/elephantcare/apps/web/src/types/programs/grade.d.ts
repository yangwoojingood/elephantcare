type GradeCategoriesType =
  | '전체'
  | '1학년'
  | '2학년'
  | '3학년'
  | '4학년'
  | '5학년'
  | '6학년'

type ClassCategoriesType = '전체' | '늘봄' | '방과후'

interface SubjectType {
  id: string
  title: string
  imageUrl?: string
  imgSrc: string
  grade: GradeCategoriesType[]
  class: string[]
  theme: string[]
  syllabus: string | null
  handout: string | null
  isTwoDepth: boolean
}
interface SubjectSubType extends SubjectType {
  subject_id: string
  order_num: number
}

export type {
  GradeCategoriesType,
  ClassCategoriesType,
  SubjectType,
  SubjectSubType
}
