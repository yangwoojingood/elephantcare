import { SubjectType } from '@types'

import { selectDataFromTable } from '@packages/supabase/database/select'
import { createClient } from '@packages/supabase/utils/client'

const fetchSubjects = async () => {
  const supabase = createClient()
  const data = await selectDataFromTable<SubjectType[]>(supabase, 'subjects')
  return data
}
export { fetchSubjects }
