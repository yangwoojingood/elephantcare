'use client'

import { useAuthStore } from '@stores'
import { useEffect } from 'react'

import { supabase } from '@packages/supabase/utils/client'

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { checkAuth } = useAuthStore()

  useEffect(() => {
    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((event) => {
      console.log('auth 상태 변경됨 event:', event)
    })
    checkAuth()
    return () => {
      subscription.unsubscribe()
    }
  }, [checkAuth])

  return <>{children}</>
}
