'use client'

import { useAuthStore } from '@/stores'
import { create } from 'domain'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { toast } from 'react-toastify'

import { createClient } from '@packages/supabase/utils/client'

import { CheckButton, CheckInput } from '@components/common'

import { ModalPortal } from './ModalPortal'

interface LoginModalProps {
  isOpen: boolean
  handleClose?: () => void
}

function LoginModal({ isOpen, handleClose = () => {} }: LoginModalProps) {
  const router = useRouter()
  const [isSignup, setIsSignup] = useState(false)
  const [isReset, setIsReset] = useState(false)
  const { checkAuth } = useAuthStore()
  const supabase = createClient()
  const handleLogin = async ({
    email,
    password
  }: {
    email: string
    password: string
  }) => {
    try {
      const response = await fetch('/api/auth/signin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      })
      if (response.ok) {
        toast.info('로그인이 완료되었습니다.')
        router.back()
        checkAuth()
      } else {
        toast.error('로그인에 실패했습니다.')
      }
    } catch (error) {
      console.error('로그인 오류:', error)
      toast.error('로그인 오류가 발생했습니다.')
    }
  }
  const handleSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    const formData = new FormData(e.currentTarget)
    const email = formData.get('email') as string
    const password = formData.get('password') as string
    const passwordConfirm = formData.get('passwordConfirm') as string
    const name = formData.get('name') as string

    // 유효성 검사
    if (!email || !password || !passwordConfirm || !name) {
      alert('모든 필드를 입력해주세요.')
      return
    }

    if (password !== passwordConfirm) {
      alert('비밀번호가 일치하지 않습니다.')
      return
    }

    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email,
          password,
          name
        })
      })

      if (response.ok) {
        toast.info('회원가입이 완료되었습니다.')
        setIsSignup(false)
      } else {
        toast.error('회원가입에 실패했습니다.')
      }
    } catch (error) {
      console.error('회원가입 에러:', error)
      alert('회원가입 중 오류가 발생했습니다.')
    }
  }
  const handleLoginModalClose = () => {
    setIsSignup(false)
    handleClose()
  }
  const handleLoginSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    handleLogin({
      email: e.currentTarget.email.value,
      password: e.currentTarget.password.value
    })
  }

  const handleResetPassword = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    try {
      const { data, error } = await supabase.auth.resetPasswordForEmail(
        e.currentTarget.email.value,
        { redirectTo: 'http://localhost:3000/auth/resetPassword' }
      )
      if (!error) {
        alert('please check your email')
      }
    } catch (error) {
      console.log(error)
    }
  }

  if (isReset) {
    return (
      <ModalPortal isOpen={isOpen} handleClose={handleLoginModalClose}>
        <div className='flex flex-col justify-between items-center h-full w-full p-4 text-lg text-deactivate font-bold'>
          <div className='flex flex-col items-center gap-y-4 mb-2 w-full'>
            <Image
              src='/assets/images/logo.png'
              alt='Logo'
              width={149}
              height={82}
            />
            <h1 className='text-xl text-black font-bold text-center'>
              비밀번호 재설정
            </h1>
            <form
              onSubmit={handleResetPassword}
              className='w-full flex flex-col py-6 gap-2'
            >
              <CheckInput
                required
                type='email'
                name='email'
                placeholder='이메일'
                size='lg'
              />
              <div className='flex flex-col gap-2 w-full'>
                <CheckButton type='submit' variant='filled' size='lg'>
                  비밀번호 재설정 메일 발송
                </CheckButton>
              </div>
            </form>
          </div>
        </div>
      </ModalPortal>
    )
  }

  if (isSignup) {
    return (
      <>
        <ModalPortal isOpen={isOpen} handleClose={handleLoginModalClose}>
          <div className='flex flex-col justify-between items-center h-full w-full p-4 text-lg text-deactivate font-bold'>
            <div className='flex flex-col items-center gap-y-4 mb-2 w-full'>
              <Image
                src='/assets/images/logo.png'
                alt='Logo'
                width={149}
                height={82}
              />
              <h1 className='text-xl text-black font-bold text-center'>
                회원가입
              </h1>
            </div>
            <form
              onSubmit={handleSignup}
              className='w-full flex flex-col py-6 gap-2'
            >
              <CheckInput
                name='name'
                required
                type='text'
                placeholder='이름'
                size='lg'
              />
              <CheckInput
                required
                type='email'
                name='email'
                placeholder='이메일'
                size='lg'
              />
              <CheckInput
                required
                name='password'
                type='password'
                placeholder='비밀번호'
                size='lg'
              />
              <CheckInput
                required
                type='password'
                name='passwordConfirm'
                placeholder='비밀번호 확인'
                size='lg'
              />
              <div className='flex items-center gap-2 mt-2 text-base'>
                <input type='checkbox' id='terms' className='w-4 h-4' />
                <label htmlFor='terms' className='text-black'>
                  이용약관 및 개인정보처리방침에 동의합니다.
                </label>
              </div>

              <div className='text-sm text-gray-500 mt-1'>
                <button className='underline'>이용약관</button> |{' '}
                <button className='underline'>개인정보처리방침</button>
              </div>

              <div className='flex flex-col gap-2 w-full'>
                <CheckButton type='submit' variant='filled' size='lg'>
                  회원가입
                </CheckButton>
                <CheckButton
                  onClick={() => setIsSignup(false)}
                  variant='outlined'
                  size='lg'
                >
                  로그인으로 돌아가기
                </CheckButton>
              </div>
            </form>
          </div>
        </ModalPortal>
      </>
    )
  }

  return (
    <ModalPortal isOpen={isOpen} handleClose={handleLoginModalClose}>
      <div className='flex flex-col justify-start items-center h-full w-full p-4 text-lg text-deactivate font-bold'>
        <div className='flex flex-col items-center gap-8 mb-2 md:mb-8'>
          <Image
            src='/assets/images/logo.png'
            alt='Logo'
            width={149}
            height={82}
          />
          <h1 className='text-xl text-black font-bold text-center'>
            위인과 함께하는 코끼리 탐구 살롱
            <br />
            로그인
          </h1>
        </div>
        <form
          onSubmit={handleLoginSubmit}
          className='w-full flex flex-col pt-10 gap-2 h-full'
        >
          <div className='space-y-2'>
            <>
              <CheckInput type='text' placeholder='아이디' name='email' />
              <CheckInput
                type='password'
                placeholder='비밀번호'
                name='password'
              />
            </>
          </div>
          <div className='space-y-2 w-full'>
            <CheckButton type='submit' variant='filled' size='lg'>
              로그인
            </CheckButton>
            <CheckButton
              onClick={() => setIsSignup(true)}
              variant='outlined'
              size='lg'
            >
              회원가입
            </CheckButton>
            <div className='flex text-base justify-center gap-4 text-deactivate'>
              <button onClick={() => setIsReset(true)}>비밀번호 재설정</button>
            </div>
          </div>
        </form>
      </div>
    </ModalPortal>
  )
}

export { LoginModal }
