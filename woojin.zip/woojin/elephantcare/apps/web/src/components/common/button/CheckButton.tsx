interface CheckButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  variant?: 'filled' | 'outlined'
}

function CheckButton({
  children,
  size = 'md',
  variant = 'filled',
  ...props
}: CheckButtonProps) {
  return (
    <button
      {...props}
      className={`${size === 'lg' ? 'w-full py-2.5' : size === 'md' ? 'w-full py-1.5' : size === 'sm' && 'w-1/3 py-1'}  ${variant === 'filled' ? 'border-btn-sky bg-btn-sky flex items-center justify-center text-white' : 'border-btn-sky bg-white flex items-center justify-center text-btn-sky'} rounded-xl border-2`}
    >
      {children}
    </button>
  )
}

export { CheckButton }
