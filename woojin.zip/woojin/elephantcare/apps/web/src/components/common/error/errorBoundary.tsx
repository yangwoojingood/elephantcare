'use client'

import { useSearchParams } from 'next/navigation'
import { Suspense, useEffect } from 'react'
import { toast } from 'react-toastify'

export default function ErrorMain() {
  const searchParams = useSearchParams()

  useEffect(() => {
    const status = searchParams.get('status')
    if (status === '403') {
      toast.error('해당 클래스를 수강할 권한이 없습니다.')
    }
  }, [searchParams, toast])
  return (
    <Suspense>
      <div />
    </Suspense>
  )
}
