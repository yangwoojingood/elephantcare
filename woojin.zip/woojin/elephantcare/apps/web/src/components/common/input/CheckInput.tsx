interface CheckInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  placeholder: string
  variant?: 'filled' | 'outlined'
  size?: 'lg' | 'md' | 'sm'
}
function CheckInput({
  placeholder,
  size = 'lg',
  variant = 'outlined',
  ...props
}: CheckInputProps) {
  const sizeClass =
    size === 'lg' ? 'py-3' : size === 'md' ? 'py-2.5 text-sm' : 'py-2 text-sm'
  return (
    <input
      type='text'
      placeholder={placeholder}
      className={`${sizeClass} w-full text-primary text-lg font-semibold ${variant === 'filled' ? 'border-btn-sky bg-white flex items-center justify-center text-btn-sky' : 'border-bordergrey border-2 rounded-lg pl-4 bg-white flex items-center justify-center'} text-deactivate placeholder:text-deactivate`}
      {...props}
    />
  )
}

export { CheckInput }
