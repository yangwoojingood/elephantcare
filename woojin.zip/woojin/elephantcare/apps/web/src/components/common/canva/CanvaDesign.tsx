'use client'

import { OverlayConfig } from '@/types'
import React, { useRef } from 'react'

interface CanvaDesignProps {
  url: string
  overlays?: OverlayConfig[]
}

export const CanvaDesign: React.FC<CanvaDesignProps> = ({ url, overlays }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null)
  return (
    <div className='relative w-full h-screen'>
      <iframe
        ref={iframeRef}
        className='absolute inset-0 w-full h-full border-0 pointer-events-auto'
        src={url}
        allow='fullscreen; microphone'
        allowFullScreen
      />
    </div>
  )
}
