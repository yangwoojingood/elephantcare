'use client'

import { useSearchParams } from 'next/navigation'
import { useEffect } from 'react'
import { toast } from 'react-toastify'

export function ErrorToast() {
  const searchParams = useSearchParams()

  useEffect(() => {
    const status = searchParams.get('status')
    if (status === '403') {
      toast.error('해당 클래스 접근 권한이 없습니다.')
    }
  }, [searchParams, toast])

  return null
}
