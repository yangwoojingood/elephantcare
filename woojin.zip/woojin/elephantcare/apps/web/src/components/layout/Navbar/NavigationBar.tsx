import Image from 'next/image'
import Link from 'next/link'

import { AuthButton } from './AuthBtn'

function NavigationBar() {
  // const session = await getServerSession();
  return (
    <>
      <nav className='h-navbar-height shrink-0 z-10 grid grid-cols-3 bg-white space-between justify-center drop-shadow-lg'>
        <div></div>
        <div className='flex items-center justify-center'>
          <Link href='/'>
            <Image
              src='/assets/images/logo_blue.png'
              alt='Logo'
              width={110}
              height={60}
            />
          </Link>
        </div>
        <div className='flex flex-1 space-x-4 max-h-full justify-end items-center mx-4'>  
          {// 알림 구현 시까지 주석 처리
          /* <Link
            href='#'
            className='bg-btn-yellow rounded-full shrink-0 p-2 w-[40px] h-[40px] md:w-[40px] md:h-[40px] flex items-center justify-center'
          >
            <Image
              src='/assets/icons/bell.svg'
              alt='Notifications'
              width={20}
              height={20}
              className='invert obejct-contain'
            />
          </Link> */}
          <AuthButton />
        </div>
      </nav>
    </>
  )
}

export { NavigationBar }
