'use client'

import { useAuthStore } from '@/stores'
import Image from 'next/image'

import { LoginButton } from '../../ui/auth'
import { NavDropDownMenu } from './NavDropDownMenu'

export function AuthButton() {
  const { isAuth, loading } = useAuthStore()
  return (
    <>
      {loading ? (
        <div className='shrink-0 w-[40px] h-[40px] md:w-[40px] md:h-[40px] flex items-center justify-center relative'>
          <Image src='/assets/icons/mypage.svg' alt='MyPage' fill />
        </div>
      ) : isAuth ? (
        <NavDropDownMenu />
      ) : (
        <LoginButton />
      )}
    </>
  )
}
