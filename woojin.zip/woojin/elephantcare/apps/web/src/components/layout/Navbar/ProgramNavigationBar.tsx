import { ProgramNavigationBarList } from '@constants'

import { ProgramNavigationBarItem } from './ProgramNavigationBarItem'

const ProgramNavigationBar = () => {
  return (
    <nav className='w-ful md:justify-center justify-start items-center h-[var(--navbar-height)] overflow-y-hidden overflow-x-auto flex gap-2 md:gap-5 text-lg md:text-xl font-cafe24'>
      {ProgramNavigationBarList.map((v) => (
        <ProgramNavigationBarItem key={v.value} {...v} />
      ))}
    </nav>
  )
}

export { ProgramNavigationBar }
