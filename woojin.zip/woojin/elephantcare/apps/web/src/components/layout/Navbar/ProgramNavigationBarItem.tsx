'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useMemo } from 'react'

const ProgramNavigationBarItem = ({
  label,
  to
}: {
  label: string
  to: string
}) => {
  const pathname = usePathname()
  return useMemo(
    () => (
      <div className='relative text-nowrap'>
        <Link
          href={to}
          className={`${pathname === to ? 'bg-skyblue text-white' : 'bg-paleblue text-skyblue'} rounded-full py-2 px-20 hover:ring-2 ring-paleblue`}
        >
          {label}
        </Link>
        <div
          className={`${pathname === to ? 'flex' : 'hidden'} absolute left-1/2 -translate-x-1/2 top-6 md:top-0 md:border-b-[40px] md:border-l-[40px] md:border-t-[40px] md:border-r-[40px] border-l-[20px] border-t-[20px] border-r-[20px] border-b-[20px] border-b-paleblue border-transparent`}
        ></div>
      </div>
    ),
    [pathname, to, label]
  )
}

export { ProgramNavigationBarItem }
