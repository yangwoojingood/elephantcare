'use client'

import { useAuthStore } from '@/stores'
import { useRouter } from 'next/navigation'
import { toast } from 'react-toastify'

export function LogOutButton() {
  const router = useRouter()
  const { setIsAuth } = useAuthStore()
  const handleLogout = async () => {
    await fetch('/api/auth/signout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    setIsAuth(false)
    toast.info('로그아웃 완료')
    router.push('/')
  }
  return (
    <button
      className='text-red-500 hover:text-red-700 cursor-pointer'
      onClick={handleLogout}
    >
      로그아웃
    </button>
  )
}
