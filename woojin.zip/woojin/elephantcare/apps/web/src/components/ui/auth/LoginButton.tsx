'use client'

import { LogInIcon } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'

import { LoginModal } from '@components/common'

export function LoginButton() {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false)

  return (
    <div>
      <Link
        href='/auth'
        className='text-gray-600 flex items-center gap-2 hover:text-gray-600 cursor-pointer rounded-md text-base'
      >
        <LogInIcon className='w-4 h-4' />
        로그인
      </Link>
      <LoginModal
        isOpen={isLoginModalOpen}
        handleClose={() => setIsLoginModalOpen(false)}
      />
    </div>
  )
}
