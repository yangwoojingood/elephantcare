import { ChevronRight } from 'lucide-react'
import { usePathname } from 'next/navigation'

import { ClassCategoriesType, GradeCategoriesType } from '@types'

import { classCategories, gradeCategories } from '@constants'

interface SubjectFilterProps {
  category: GradeCategoriesType | ClassCategoriesType
  handleFilterSubject: (
    category: GradeCategoriesType | ClassCategoriesType
  ) => void
}
function SubjectFilter({ category, handleFilterSubject }: SubjectFilterProps) {
  const pathname = usePathname()
  const segments = pathname.split('/').filter((segment) => segment)
  const segment = segments[2]
  console.log(segment)
  let categoreis: (GradeCategoriesType | ClassCategoriesType)[] = []
  if (segment === 'grade') {
    categoreis = gradeCategories
  }
  if (segment === 'class') {
    categoreis = classCategories
  }
  return (
    <div className='w-full font-cafe24 text-lg whitespace-nowrap md:text-2xl items bg-skyblue overflow-hidden  h-full rounded-2xl'>
      <div className='overflow-x-auto w-full flex flex-row md:flex-col'>
        {categoreis.map((item, index) => (
          <button
            key={index}
            className={`w-full md:p-4 border-b-2 items-center flex justify-between ${
              item === category
                ? 'bg-white text-skyblue'
                : 'bg-skyblue text-white'
            }`}
            onClick={() => handleFilterSubject(item)}
          >
            <span className='pl-4'>{item}</span>
            {item === category && <ChevronRight size={24} />}
          </button>
        ))}
      </div>
    </div>
  )
}
export { SubjectFilter }
