'use client'

import { useMemo } from 'react'

import { useSubjects } from '@hooks'

import { Spinner } from '@components/ui'

import { SubjectFilter } from './filter'
import { SubjectList } from './list'

function SubjectMain({ filter }: { filter: string }) {
  const {
    category,
    handleFilterSubject,
    handleSearchSubject,
    filteredSubjects,
    isLoading
  } = useSubjects()

  return useMemo(
    () => (
      <>
        <div className='w-full overflow-x-auto md:w-1/6 shrink-0 h-fit pt-3'>
          <SubjectFilter
            category={category}
            handleFilterSubject={handleFilterSubject}
          />
        </div>
        <div className='flex-1 pt-3 justify-center items-center'>
          {isLoading ? (
            <Spinner />
          ) : (
            <SubjectList
              handleSearchSubject={handleSearchSubject}
              filteredSubjects={filteredSubjects}
            />
          )}
        </div>
      </>
    ),
    [
      filteredSubjects,
      handleSearchSubject,
      isLoading,
      category,
      handleFilterSubject
    ]
  )
}

export { SubjectMain }
