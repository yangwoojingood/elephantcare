'use client'

import Image from 'next/image'
import Link from 'next/link'

import { SubjectType } from '@types'

import { useSubjectSearch } from '@hooks'

import { buttonColors } from '@constants'

interface SubjectListProps {
  filteredSubjects: SubjectType[]
  handleSearchSubject: (search: string) => void
}
function SubjectList({
  filteredSubjects,
  handleSearchSubject
}: SubjectListProps) {
  const { search, handleSearch } = useSubjectSearch(handleSearchSubject)

  return (
    <div className='flex flex-col items-start w-full h-full'>
      <div className='flex justify-between items-start w-full pb-1 md:pb-2'>
        <div className='group flex overflow-hidden w-full max-w-80 text-base bg-background rounded-2xl p-1'>
          <div className='flex items-center justify-between w-full'>
            <input
              type='text'
              className='outline-none w-full h-full'
              value={search}
              onChange={handleSearch}
            />
            <button type='submit'>
              <Image
                src='/assets/icons/search.svg'
                alt='search'
                width={24}
                height={24}
              />
            </button>
          </div>
        </div>
        <div className='flex'>
          <div className='relative flex w-full text-lg font-nanum font-semibold'>
            <button className='text-skyblue p-2 text-nowrap'>이름순 ↓</button>
          </div>
        </div>
      </div>
      <div className='grid grid-cols-1 flex-1 md:grid-cols-2 lg:grid-cols-3 overflow-y-auto md:pr-10 content-start gap-x-4 w-full h-full'>
        {filteredSubjects?.map((item, index) => {
          return (
            <div
              key={index}
              className='flex flex-col aspect-square items-center'
            >
              <Link
                href={`${!item.isTwoDepth ? `/classes/${item.id}` : `/programs/sub/${item.id}`} `}
                className='w-full shadow-xl'
              >
                <div className='relative w-full pb-[75%]'>
                  <Image
                    src={item.imageUrl || `/assets/images/${item.imgSrc}`}
                    alt={item.title}
                    className='absolute top-0 left-0 w-full h-full object-cover'
                    layout='fill'
                  />
                </div>
                <div
                  className={`${buttonColors[index % buttonColors.length]} text-xl flex items-center justify-center font-cafe24 w-full text-white text-center py-2 md:h-16`}
                >
                  {item.title}
                </div>
              </Link>
            </div>
          )
        })}
      </div>
    </div>
  )
}
export { SubjectList }
