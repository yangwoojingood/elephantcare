'use client'

import { useClassList } from '@/hooks/useClassList'
import { ClassItemType } from '@/types'
import { ChevronLeft } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

import { createClient } from '@packages/supabase/utils/client'

function ClassLists({ id, subId }: { id: string; subId?: string }) {
  const pathname = usePathname()

  // Regular expression to match "/classes/<uuid>/<uuid>"
  const classesRegex = /^\/classes\/([0-9a-fA-F-]+)\/([0-9a-fA-F-]+)$/
  const match = pathname.match(classesRegex)

  // If the URL matches, extract the first UUID
  const destination = match
    ? `/programs/sub/${match[1]}`
    : '/programs/main/grade'

  const supabase = createClient()

  const { subjectData, classData } = useClassList(id, subId)
  const { data: syllabusUrl } = supabase.storage
    .from('programs')
    .getPublicUrl(subjectData?.syllabus as string)

  const getHandoutPublicUrl = (handout: string) => {
    return supabase.storage.from('programs').getPublicUrl(handout).data
      ?.publicUrl
  }

  return (
    <div className='h-full'>
      <div className='h-navbar-height flex items-center text-3xl px-10'>
        <Link
          href={destination}
          replace
          className='text-skyblue font-bold pr-10'
        >
          <ChevronLeft size={38} />
        </Link>
        <div className='font-cafe24'>{subjectData?.title}</div>
        {subjectData?.syllabus && (
          <Link
            href={syllabusUrl.publicUrl}
            className='h-[45px]'
            target='_blank'
          >
            <div className='bg-btn-green text-white flex items-center text-xl h-full ml-5 text-center py-1 px-5 font-cafe24 rounded-full hover:ring-2 ring-btn-green'>
              <span>강의 계획서 다운로드</span>
            </div>
          </Link>
        )}
      </div>
      <div className='bg-white rounded-3xl overflow-y-auto h-[calc(100vh-2*(var(--navbar-height)))]'>
        <div className='flex flex-col gap-5 pt-5 w-full'>
          {classData.length > 0 &&
            classData?.map((classItem: ClassItemType, index: number) => (
              <div
                key={index}
                className='w-full border-b-2 pl-20 pb-5 flex flex-row items-center justify-between border-paleblue'
              >
                <div className='text-2xl font-bold'>
                  {classItem.order_num}. {classItem.title}
                </div>
                <div className='justify-start min-w-[20%]'>
                  <div className='text-white flex flex-row gap-3'>
                    {classItem?.url && (
                      <Link href={`/class/${classItem.id}`}>
                        <div className='bg-skyblue h-full text-center py-2 px-10 font-cafe24 rounded-full hover:ring-2 ring-skyblue'>
                          학습하기
                        </div>
                      </Link>
                    )}
                    {classItem?.handout && (
                      <div className='group relative'>
                        <Link
                          href={getHandoutPublicUrl(classItem.handout)}
                          download={true}
                          target='_blank'
                        >
                          <div className='bg-btn-red aspect-square h-full px-2 py-1 flex items-center justify-center text-center rounded-full font-cafe24 hover:ring-2 ring-btn-red'>
                            <Image
                              src='/assets/images/material.png'
                              alt='material'
                              width={33}
                              height={42}
                            />
                          </div>
                        </Link>
                        <div className='absolute top-full w-20 text-center mt-2 z-10 left-1/2 transform -translate-x-1/2 py-1 bg-deactivate text-white text-sm rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none'>
                          활동지 다운
                        </div>
                      </div>
                    )}
                    {classItem?.extra_url && (
                      <div className='group relative'>
                        <Link href={`/extra/${classItem.id}`}>
                          <div className='bg-btn-yellow aspect-square h-full flex items-center justify-center text-center rounded-full font-cafe24 hover:ring-2 ring-btn-red'>
                            <Image
                              src='/assets/images/extra.png'
                              alt='extra'
                              width={42}
                              height={42}
                            />
                          </div>
                        </Link>
                        <div className='absolute top-full w-16 text-center mt-2 z-10 left-1/2 transform -translate-x-1/2 py-1 bg-deactivate text-white text-sm rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none'>
                          보충 자료
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          {classData.length === 0 && (
            <div className='text-center text-2xl font-bold'>
              학습지가 없습니다.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
export { ClassLists }
