'use client'

import { useSubjectSubList } from '@/hooks/useSubjectSubList'
import { SubjectSubType } from '@/types'
import Image from 'next/image'
import Link from 'next/link'
import { ChevronLeft } from 'lucide-react'

export function SubClassLists({ id }: { id: string }) {
  const { subjectData, subSubjectData } = useSubjectSubList(id)

  return (
    <div className='h-[calc(100vh-(var(--navbar-height)))] bg-paleblue'>
      <div className='h-navbar-height flex items-center text-3xl px-10'>
        <Link
          href='/programs/main/grade'
          replace
          className='text-skyblue font-bold pr-10'
        >
          <ChevronLeft size={38} />
        </Link>
        <div className='font-cafe24'>{subjectData?.title}</div>
      </div>
      <div className='bg-white rounded-3xl px-10 overflow-y-auto h-[calc(100vh-2*(var(--navbar-height)))]'>
        <div className='flex flex-wrap gap-10 justify-between mx-auto px-4 pt-5 w-full'>
          {subSubjectData?.map(
            (subSubjectItem: SubjectSubType, index: number) => (
              <Link
                href={`/classes/${id}/${subSubjectItem.id}`}
                key={index}
                className='w-[22%] aspect-square flex flex-col'
              >
                <p className='text-2xl font-cafe24 font-bold h-10'>
                  {subSubjectItem.order_num}. {subSubjectItem.title}
                </p>
                <div className='flex-1 relative'>
                  <Image
                    src={subSubjectItem.imageUrl || '/'}
                    alt={subSubjectItem.title}
                    fill
                  />
                </div>
              </Link>
            )
          )}
          
        </div>
      </div>
    </div>
  )
}
