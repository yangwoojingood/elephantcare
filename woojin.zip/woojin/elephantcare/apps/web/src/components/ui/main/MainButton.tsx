import Image from 'next/image'
import Link from 'next/link'

import { MainButtonType } from '@types'

interface MainButtonProps {
  item: MainButtonType
  idx: number
}

const MainButton = ({ item, idx }: MainButtonProps) => (
  <Link
    style={{ animation: `slideUp ${0.15 * idx}s ease-in-out` }}
    className={`relative w-full flex flex-col h-full rounded-xl p-3 md:p-4 hover:ring-2 ${item.ringColor} ${item.className} ${item.bgColor}`}
    href={item.href}
  >
    {item.title.map((text, index) => (
      <span key={index}>{text}</span>
    ))}
    <div className={`absolute ${item.imagePosition} bottom-0 right-0 flex`}>
      <Image
        src={item.image}
        alt={item.id}
        width={item.imageSize.width}
        height={item.imageSize.height}
        className='w-full h-full'
      />
    </div>
  </Link>
)
export { MainButton }
