import {
  ClassCategoriesType,
  ClassItemType,
  GradeCategoriesType,
  ProgramNavigationBarItemType,
  SubjectType
} from '@types'

const ProgramNavigationBarList: ProgramNavigationBarItemType[] = [
  {
    label: '수업별',
    value: 'class',
    to: '/programs/main/class'
  },
  {
    label: '학년별',
    value: 'grade',
    to: '/programs/main/grade'
  }

  // {
  //   label: '주제별',
  //   value: 'theme',
  //   to: '/programs/main/theme'
  // }
]

const gradeCategories: GradeCategoriesType[] = [
  '전체',
  '1학년',
  '2학년',
  '3학년',
  '4학년',
  '5학년',
  '6학년'
]

const classCategories: ClassCategoriesType[] = ['전체', '늘봄', '방과후']
export { ProgramNavigationBarList, gradeCategories, classCategories }
