const buttonColors = [
  'bg-btn-yellow',
  'bg-btn-green',
  'bg-skyblue',
  'bg-btn-navy',
  'bg-btn-red',
  'bg-btn-purple'
]

export { buttonColors }
