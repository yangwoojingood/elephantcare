import { MainButtonType } from '@types'

const MAIN_BUTTONS: MainButtonType[] = [
  {
    id: 'program',
    title: ['프로그램', '선택'],
    href: '/programs/main/class',
    bgColor: 'bg-btn-sky',
    ringColor: 'ring-btn-sky',
    image: '/assets/images/main_1.png',
    imageSize: { width: 183, height: 184 },
    className: 'row-span-2 text-2xl md:text-4xl',
    imagePosition: 'h-2/3 right-2 md:right-4 bottom-2 md:bottom-4'
  },
  {
    id: 'syllabus',
    title: ['수업계획서', '생성'],
    href: '/no-permission',
    bgColor: 'bg-btn-green',
    ringColor: 'ring-btn-green',
    image: '/assets/images/main_2.png',
    imageSize: { width: 146, height: 123 },
    className: 'row-span-2 text-lg md:text-2xl',
    imagePosition: 'h-2/3 right-2 md:right-4 bottom-2 md:bottom-4'
  }
]

const SIDE_BUTTONS: MainButtonType[] = [
  {
    id: 'handout',
    title: ['학습지', '다운로드'],
    href: '/no-permission',
    bgColor: 'bg-btn-red',
    ringColor: 'ring-btn-red',
    className: 'text-lg md:text-2xl',
    image: '/assets/images/main_3.png',
    imageSize: { width: 117, height: 122 },
    imagePosition: 'h-2/3 right-2 md:right-4 bottom-2 md:bottom-4'
  },
  {
    id: 'student',
    title: ['학생관리'],
    href: '/no-permission',
    bgColor: 'bg-btn-yellow',
    className: 'text-lg md:text-2xl',
    ringColor: 'ring-btn-yellow',
    image: '/assets/images/main_4.png',
    imageSize: { width: 113, height: 105 },
    imagePosition: 'h-2/3 right-2 md:right-4 bottom-2 md:bottom-4'
  }
]

export { MAIN_BUTTONS, SIDE_BUTTONS }
