import { cookies } from 'next/headers'
import { NextRequest } from 'next/server'

import { createClient } from '@packages/supabase/utils/server'

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()
    if (!email || !password) {
      return new Response(
        JSON.stringify({ error: '이메일과 비밀번호를 입력해주세요.' }),
        { status: 400 }
      )
    }

    const supabase = await createClient()

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })

    if (error) {
      console.error('Signin error:', error)
      return new Response(
        JSON.stringify({ error: '이메일 또는 비밀번호가 올바르지 않습니다.' }),
        { status: 401 }
      )
    }

    // 세션 쿠키 설정
    const cookieStore = await cookies()
    cookieStore.set('sb-access-token', data.session?.access_token || '', {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24
    })

    cookieStore.set('sb-refresh-token', data.session?.refresh_token || '', {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7
    })

    return new Response(
      JSON.stringify({
        message: '로그인이 완료되었습니다.',
        user: data.user
      }),
      { status: 200 }
    )
  } catch (error) {
    console.error('Unexpected error:', error)
    return new Response(
      JSON.stringify({ error: '서버 오류가 발생했습니다.' }),
      { status: 500 }
    )
  }
}
