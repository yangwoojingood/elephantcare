// app/api/signup/route.ts
import { NextRequest, NextResponse } from 'next/server'

import { createClient } from '@packages/supabase/utils/server'

export async function POST(request: NextRequest): Promise<
  | NextResponse<{
      error: string
    }>
  | NextResponse<{
      message: string
    }>
> {
  try {
    const { email, password, name } = await request.json()

    if (!email || !password || !name) {
      return NextResponse.json(
        { error: '필수 정보가 누락되었습니다.' },
        { status: 400 }
      )
    }

    const supabase = await createClient()

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { name }
      }
    })

    if (error) {
      console.error('Signup error:', error)
      return NextResponse.json(
        { error: error.message },
        { status: error.status || 400 }
      )
    }

    return NextResponse.json({
      message: '회원가입이 완료되었습니다.',
      user: data.user
    })
  } catch (error) {
    console.error('Unexpected error:', error)
    return NextResponse.json(
      { error: '서버 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
