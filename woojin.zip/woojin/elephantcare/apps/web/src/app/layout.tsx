import type { Metadata } from 'next'
import { ToastContainer } from 'react-toastify'

import '@packages/ui/globals.css'

import { AuthProvider, ThemeProvider } from '../components/providers'
import { nanumSquareNeo } from './fonts'
import { cafe24ssurround } from './fonts'

export const metadata: Metadata = {
  title: '코끼리가그랬어 놀봄교실'
}

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang='ko' suppressHydrationWarning>
      <body
        className={`${cafe24ssurround.variable} ${nanumSquareNeo.variable} antialiased h-screen flex flex-col text-2xl`}
      >
        <ThemeProvider>
          <AuthProvider>
            {children}
            <ToastContainer className={'text-base'} position='bottom-right' />
            <div id='modal-root' />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
