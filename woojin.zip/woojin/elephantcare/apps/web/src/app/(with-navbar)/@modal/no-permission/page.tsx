'use client'

import { useRouter } from 'next/navigation'

import {
  Dialog,
  DialogContent,
  DialogTitle
} from '@packages/ui/components/dialog'

export default function NoPermission() {
  const router = useRouter()

  return (
    <Dialog open={true} onOpenChange={() => router.back()}>
      <DialogContent>
        <DialogTitle>알림</DialogTitle>
        <div className='flex flex-col justify-between items-center p-4 text-lg text-deactivate font-bold'>
          <div className='flex flex-col items-center gap-y-4 mb-2 w-full'>
            <h1 className='text-xl text-black font-bold text-center'>
              권한이 없습니다.
            </h1>
          </div>{' '}
        </div>
      </DialogContent>
    </Dialog>
  )
}
