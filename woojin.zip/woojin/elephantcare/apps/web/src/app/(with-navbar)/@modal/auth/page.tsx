'use client'

import { LoginModal } from '@/components'
import { Dialog } from '@radix-ui/react-dialog'
import { useRouter } from 'next/navigation'

export default function AuthModal() {
  const router = useRouter()

  return (
    <Dialog open={true} onOpenChange={() => router.back()}>
      <LoginModal isOpen={true} handleClose={() => router.back()} />
    </Dialog>
  )
}
