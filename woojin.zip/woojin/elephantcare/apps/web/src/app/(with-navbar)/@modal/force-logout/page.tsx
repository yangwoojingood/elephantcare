'use client'

import { CheckButton } from '@/components'
import { useRouter } from 'next/navigation'

import {
  Dialog,
  DialogContent,
  DialogTitle
} from '@packages/ui/components/dialog'

export default function NoPermission() {
  const router = useRouter()

  return (
    <Dialog open={true} onOpenChange={() => router.back()}>
      <DialogContent>
        <DialogTitle>알림</DialogTitle>
        <div className='flex flex-col justify-between items-center p-4 text-lg text-deactivate font-bold'>
          <div className='flex flex-col items-center gap-y-4 mb-2 w-full'>
            <h1 className='text-xl text-black font-bold text-center'>
              다른 사용자가 같은 아이디로 로그인을 시도해 <br /> 로그아웃
              되었습니다.
            </h1>
            <CheckButton
              onClick={() => router.replace('/auth')}
              variant='filled'
              size='lg'
            >
              다시 로그인하기
            </CheckButton>
          </div>{' '}
        </div>
      </DialogContent>
    </Dialog>
  )
}
