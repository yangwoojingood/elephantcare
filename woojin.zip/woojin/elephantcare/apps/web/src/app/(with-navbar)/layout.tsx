import { Metadata } from 'next'

import { NavigationBar } from '@components/layout/Navbar/NavigationBar'

export const metadata: Metadata = {
  title: '코끼리가그랬어 놀봄교실',
  icons: {
    icon: '/favicon.svg'
  }
}

export default function RootLayout({
  children,
  modal
}: {
  children: React.ReactNode
  modal?: React.ReactNode
}) {
  return (
    <div className='relative h-screen flex flex-col w-full'>
      <NavigationBar />
      <div className='flex-1 shrink-0'>
        {children} {modal}
      </div>
    </div>
  )
}
