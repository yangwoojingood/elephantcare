import { SubjectMain } from '@components/ui'

export default async function Page() {
  return (
    <div className='h-full w-full flex flex-col text-2xl'>
      <div className='flex md:flex-row bg-paleblue flex-col w-full px-4 md:px-8 gap-4 md:gap-12 h-[calc(100vh-var(--navbar-height)*2)] '>
        <SubjectMain filter='all' />
      </div>
    </div>
  )
}
