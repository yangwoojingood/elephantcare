import { ClassLists } from '@/components/ui/classes/ClassList'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: '수업',
  description: '수업 페이지입니다.'
}
interface Props {
  params: Promise<{ id: string[] }>
}

export default async function Page({ params }: Props) {
  const { id } = await params
  return (
    <div className='h-[calc(100vh-var(--navbar-height))] bg-paleblue'>
      <ClassLists id={id[0]!} subId={id[1]} />
    </div>
  )
}
