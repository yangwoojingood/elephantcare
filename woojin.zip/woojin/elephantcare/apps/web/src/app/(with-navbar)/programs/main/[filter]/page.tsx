import { SubjectMain } from '@/components'

import { ProgramNavigationBar } from '@components/layout/Navbar/ProgramNavigationBar'

interface Props {
  params: Promise<{ filter: string }>
}

export default async function Page({ params }: Props) {
  const { filter } = await params
  return (
    <div className='h-full w-full flex flex-col text-2xl'>
      <ProgramNavigationBar />
      <div className='flex md:flex-row bg-paleblue flex-col w-full px-4 md:px-8 gap-4 md:gap-12 h-[calc(100vh-var(--navbar-height)*2)] '>
        <SubjectMain filter={filter} />
      </div>
    </div>
  )
}
