import { ErrorToast } from '@/components/common/error/errorToast'
import Link from 'next/link'
import { Suspense } from 'react'

import { MAIN_BUTTONS, SIDE_BUTTONS } from '@constants'

import { MainButton } from '@components/ui'

export default async function Home() {
  return (
    <div className="w-full h-full flex justify-center items-center text-2xl bg-no-repeat bg-bottom bg-contain bg-[url('/assets/images/bottom_sheet.png')]">
      <div className='grid gird-cols-1 md:grid-cols-2 px-6 md:px-0 w-full h-3/4 md:w-3/4 mb-10 text-white font-cafe24 text-2xl gap-2 md:gap-4'>
        <div className='grid grid-rows-3 gap-2 md:gap-4'>
          {MAIN_BUTTONS.map((button, idx) => (
            <MainButton key={button.id} item={button} idx={idx + 1} />
          ))}
        </div>
        <div className='grid grid-rows-3'>
          <div className='row-span-2 grid grid-rows-2 gap-2 md:gap-4 mb-4'>
            {SIDE_BUTTONS.map((button, idx) => (
              <MainButton key={button.id} item={button} idx={idx + 3} />
            ))}
          </div>
          <Link
            className='w-full h-full rounded-xl text-2xl p-4 bg-paleyellow hover:ring-2 ring-paleyellow'
            href='/#'
          >
            <div className='w-full text-btn-yellow'>comming soon...</div>
          </Link>
        </div>
        <Suspense fallback={null}>
          <ErrorToast />
        </Suspense>
      </div>
    </div>
  )
}
