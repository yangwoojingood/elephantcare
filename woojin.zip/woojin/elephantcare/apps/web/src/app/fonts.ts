import localFont from 'next/font/local'

const nanumSquareNeo = localFont({
  src: [
    {
      path: '../../../../packages/shared/fonts/nanumgothic/NanumSquareNeo-Variable.woff2',
      weight: '45 920',
      style: 'normal'
    }
  ],
  variable: '--font-nanum'
})
const cafe24ssurround = localFont({
  src: [
    {
      path: '../../../../packages/shared/fonts/cafe24ssurround/Cafe24Ssurround-v2.0.woff2',
      weight: '45 920',
      style: 'normal'
    }
  ],
  variable: '--font-cafe24'
})
export { nanumSquareNeo, cafe24ssurround }
