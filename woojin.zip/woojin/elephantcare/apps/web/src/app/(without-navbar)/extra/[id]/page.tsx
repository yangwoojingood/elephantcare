import { CanvaDesign } from '@/components/common/canva/CanvaDesign'
import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'

import { createClient } from '@packages/supabase/utils/server'

export const revalidate = 0

type Props = {
  params: {
    id: string
  }
}

export default async function Page({ params }: Props) {
  const { id } = await params
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('classes')
    .select('*')
    .eq('id', id)
    .single()
  if (error) {
    throw error
  }
  const classData = data

  return (
    <div className='relative min-h-screen'>
      <Link href={`/classes/${classData.subject_id}`}>
        <div className='hover:ring-2 ring-btn-yellow absolute top-10 left-10 w-14 h-14 flex justify-center items-center rounded-xl bg-btn-yellow text-white z-10'>
          <ChevronLeft size={38} className='font-bold' />
        </div>
      </Link>
      <CanvaDesign url={data.extra_url} />
    </div>
  )
}
