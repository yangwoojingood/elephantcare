'use client'

import React from 'react'
import { useEffect } from 'react'

import { createClient } from '@packages/supabase/utils/client'

const resetPassword = () => {
  const supabase = createClient()
  useEffect(() => {
    supabase.auth.onAuthStateChange(async (event, session) => {
      if (event == 'PASSWORD_RECOVERY') {
        const newPassword = prompt(
          'What would you like your new password to be?'
        )
        const { data, error } = await supabase.auth.updateUser({
          password: newPassword as string
        })

        if (data) alert('Password updated successfully!')
        if (error) alert('There was an error updating your password.')
      }
    })
  }, [])
  return <div>resetPass</div>
}

export default resetPassword
