import { gradeCategories } from '@/constants'
import { ClassCategoriesType, GradeCategoriesType } from '@/types'
import { SubjectType } from '@/types'

const filterSubject = (
  subjects: SubjectType[],
  category: GradeCategoriesType | ClassCategoriesType
) => {
  if (category === '전체') return subjects
  if (gradeCategories.includes(category as GradeCategoriesType)) {
    return subjects?.filter((subject) => {
      return subject.grade.includes(category as GradeCategoriesType)
    })
  }
  return subjects?.filter((subject) => {
    return subject.class.includes(category as ClassCategoriesType)
  })
}

export { filterSubject }
