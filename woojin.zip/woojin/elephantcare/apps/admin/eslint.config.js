import { nextJsConfig } from "@packages/eslint-config/next-js"

/** @type {import("eslint").Linter.Config} */
export default nextJsConfig
