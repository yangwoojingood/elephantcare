import { ClassList } from '@/components/ui/class/classList'
import { SubClassList } from '@/components/ui/subject/subSubjectList'

interface Props {
  params: Promise<{ id: string[] }>
}
export default async function ClassListPage({ params }: Props) {
  const { id } = await params
  return (
    <div className='max-w-5xl mx-auto w-full px-2 md:px-4'>
      <div className='justify-between items-center mt-10'>
        <h1 className='text-2xl font-bold'>과목 관리</h1>
      </div>

      {id?.[0] === 'sub' ? (
        <SubClassList id={id?.[1] || ''} />
      ) : (
        <ClassList id={id[0] || ''} isSub={id[1] === 'sub'} />
      )}
    </div>
  )
}
