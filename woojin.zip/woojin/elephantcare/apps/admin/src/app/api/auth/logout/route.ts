import { NextRequest, NextResponse } from 'next/server'

import { createClient } from '@packages/supabase/utils/server'

export async function POST(request: NextRequest): Promise<
  | NextResponse<{
      error: string
    }>
  | NextResponse<{
      message: string
    }>
> {
  try {
    const supabase = await createClient()
    const { error } = await supabase.auth.signOut()

    if (error) {
      return NextResponse.json({ error: '로그아웃 실패' }, { status: 500 })
    }

    return NextResponse.json({ message: '로그아웃 완료' })
  } catch (error) {
    return NextResponse.json(
      { error: '서버 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
