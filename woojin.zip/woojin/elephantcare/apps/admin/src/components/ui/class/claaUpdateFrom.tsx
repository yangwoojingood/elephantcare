'use client'

import { Upload } from 'lucide-react'
import { useState } from 'react'

import { uploadFile } from '@packages/supabase/storage/upload'
import { createClient } from '@packages/supabase/utils/client'
import { Button } from '@packages/ui/components/button'
import { Input } from '@packages/ui/components/input'
import { Label } from '@packages/ui/components/label'
import { Textarea } from '@packages/ui/components/textarea'

interface ClassUpdateFormProps {
  parentId: string
  isSub: boolean
  initialData: {
    classId: string
    title: string
    url: string
    extra_url?: string
    order_num: number
    handout: string // existing file URL
  }
  handleClose: () => void
}

interface FormData {
  title: string
  url: string
  extra_url?: string
  order_num: number
  handoutFile: File | null
}

export function ClassUpdateForm({
  parentId,
  isSub,
  initialData,
  handleClose
}: ClassUpdateFormProps) {
  const [formData, setFormData] = useState<FormData>({
    title: initialData.title,
    url: initialData.url,
    extra_url: initialData?.extra_url,
    order_num: initialData.order_num,
    handoutFile: null
  })
  const [isSubmitLoading, setIsSubmitLoading] = useState(false)

  const handleFormChange = (key: string, value: string | number | File) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitLoading(true)

    try {
      const supabase = createClient()
      // If a new file is uploaded, use it; otherwise, keep the existing file URL.
      let handout = initialData.handout
      if (formData.handoutFile) {
        const { error } = await supabase.storage
          .from('programs')
          .remove([initialData.handout])
        if (error) {
          console.error('Error deleting existing handout:', error)
          return
        }
        handout = await uploadFile(supabase, 'handout', formData.handoutFile)
      }

      // Update the class record based on its ID
      const { error } = await supabase
        .from('classes')
        .update({
          title: formData.title,
          url: formData.url,
          extra_url: formData.extra_url,
          order_num: formData.order_num,
          handout: handout,
          ...(isSub ? { category_id: parentId } : { subject_id: parentId })
        })
        .eq('id', initialData.classId)

      if (error) {
        console.error('Error updating class:', error)
      } else {
        handleClose()
      }
    } catch (error) {
      console.error('Error:', error)
    } finally {
      setIsSubmitLoading(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      handleFormChange('handoutFile', e.target.files[0])
    }
  }

  return (
    <div className='w-full h-full p-5'>
      <form
        onSubmit={handleSubmit}
        className='justify-between h-full flex flex-col'
      >
        <div className='flex-1 pb-4 space-y-4 md:max-h-[50rem] overflow-y-auto'>
          <div className='space-y-2'>
            <Label htmlFor='title'>제목</Label>
            <Input
              id='title'
              placeholder='제목을 입력하세요'
              value={formData.title}
              onChange={(e) => handleFormChange('title', e.target.value)}
              className='h-12'
            />
          </div>

          <div className='space-y-2'>
            <Label htmlFor='url'>URL</Label>
            <Textarea
              id='url'
              placeholder='URL을 입력하세요'
              value={formData.url}
              onChange={(e) => handleFormChange('url', e.target.value)}
              className='min-h-[100px] resize-none'
            />
          </div>

          <div className='space-y-2'>
            <Label htmlFor='extra_url' className=''>
              EXTRA_URL
            </Label>
            <Textarea
              id='extra_url'
              placeholder='보충자료 URL을 입력하세요'
              value={formData.extra_url || ''}
              onChange={(e) => handleFormChange('extra_url', e.target.value)}
              className='min-h-[100px] resize-none'
            />
          </div>

          <div className='space-y-2'>
            <Label htmlFor='order_num'>순서</Label>
            <Input
              id='order_num'
              type='number'
              placeholder='순서를 입력하세요'
              value={formData.order_num}
              onChange={(e) =>
                handleFormChange('order_num', parseInt(e.target.value) || 0)
              }
              className='h-12'
            />
          </div>

          <div className='space-y-2'>
            <Label>수업 자료</Label>
            <div className='border-2 border-dashed rounded-lg p-8 bg-gray-50'>
              <Input
                type='file'
                accept='.hwp,.pdf'
                onChange={handleFileChange}
                className='hidden'
                id='file-upload-update'
              />
              <Label
                htmlFor='file-upload-update'
                className='flex flex-col items-center cursor-pointer'
              >
                <Upload className='w-12 h-12 mb-2 text-gray-400' />
                <span>
                  {formData.handoutFile
                    ? formData.handoutFile.name
                    : initialData.handout
                      ? `현재 파일: ${initialData.handout.split('/').pop()} (클릭하여 교체)`
                      : '파일을 선택하세요. 파일의 이름은 영어/숫자만 가능합니다.'}
                </span>
              </Label>
            </div>
          </div>
        </div>

        <div className='flex gap-2 pb-10'>
          <Button
            type='button'
            variant='outline'
            onClick={handleClose}
            className='flex-1 h-12'
          >
            취소
          </Button>
          <Button
            type='submit'
            className='flex-1 h-12'
            disabled={isSubmitLoading}
          >
            {isSubmitLoading ? '저장 중...' : '저장'}
          </Button>
        </div>
      </form>
    </div>
  )
}
