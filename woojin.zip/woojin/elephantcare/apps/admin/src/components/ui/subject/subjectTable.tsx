'use client'

import { ModalPortal } from '@/components/common'
import { SubjectType } from '@/types'
import { EllipsisIcon } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useState } from 'react'

import { useSubjects } from '@hooks'

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@packages/ui/components/dropdown-menu'
import { Spinner } from '@packages/ui/components/spinner'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@packages/ui/components/table'

type GradeCategoriesType =
  | '전체'
  | '1학년'
  | '2학년'
  | '3학년'
  | '4학년'
  | '5학년'
  | '6학년'

export function SubjectTable() {
  const {
    filteredSubjects,
    handleSearchSubject,
    handleFilterSubject,
    handleDeleteSubject
  } = useSubjects()
  const [isOpen, setIsOpen] = useState(false)
  const router = useRouter()
  const handleDelete = (id: string) => {
    const a = confirm('정말 삭제하시겠습니까?')
    if (a) {
      handleDeleteSubject(id)
    }
  }
  const handleOpenClass = (subject: SubjectType) => {
    if (subject.isTwoDepth) {
      router.push(`/main/subject/list/sub/${subject.id}`)
    } else {
      router.push(`/main/subject/list/${subject.id}`)
    }
  }
  return (
    <div className='pb-10'>
      <p className='text-sm mt-4 text-gray-500 font-semibold'>
        전체 과목{' '}
        <span className='text-blue-500'>{filteredSubjects.length}</span>개
      </p>
      <Table className='mt-4 overflow-y-auto max-h-[calc(100vh-4rem-2.5rem)] h-full px-4'>
        <TableHeader>
          <TableRow className='bg-gray-100'>
            <TableHead>id</TableHead>
            <TableHead>제목</TableHead>
            <TableHead>학년</TableHead>
            <TableHead>class</TableHead>
            <TableHead>주제</TableHead>
            <TableHead>강의 계획서</TableHead>
            <TableHead>2depth</TableHead>
            <TableHead>수업 보기</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className='overflow-y-auto max-h-[calc(100vh-4rem-2.5rem)] h-full'>
          {filteredSubjects.map((subject, index) => (
            <TableRow key={subject.id} className='h-12'>
              <TableCell className='truncate'>{index + 1}</TableCell>
              <TableCell>{subject.title || 'null'}</TableCell>
              <TableCell>{subject.grade.join(', ') || ''}</TableCell>
              <TableCell>{subject.class.join(', ') || ''}</TableCell>
              <TableCell>{subject.theme || ''}</TableCell>
              <TableCell>{subject.syllabus || ''}</TableCell>
              <TableCell>{subject.isTwoDepth ? 'O' : 'X'}</TableCell>
              <TableCell>
                <p
                  className='text-gray-500 cursor-pointer'
                  onClick={() => {
                    handleOpenClass(subject)
                  }}
                >
                  수업 보기
                </p>
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger>
                    <EllipsisIcon className='h-4' />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className='rounded-lg'>
                    <DropdownMenuItem className='flex justify-center w-full h-full cursor-pointer'>
                      <p
                        className='text-red-500'
                        onClick={() => {
                          handleDelete(subject.id)
                        }}
                      >
                        삭제
                      </p>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
