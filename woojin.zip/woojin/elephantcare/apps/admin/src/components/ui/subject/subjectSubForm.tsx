'use client'

import { Upload } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'react-toastify'

import { insertDataToTable } from '@packages/supabase/database/insert'
import { uploadImage } from '@packages/supabase/storage/upload'
import { createClient } from '@packages/supabase/utils/client'
import { Button } from '@packages/ui/components/button'
import { Card, CardContent } from '@packages/ui/components/card'
import { Input } from '@packages/ui/components/input'
import { Label } from '@packages/ui/components/label'

interface SubjectSubFormProps {
  id: string | number // subject_id로 사용될 id
  handleClose: () => void
}

export function SubjectSubForm({ id, handleClose }: SubjectSubFormProps) {
  const [formData, setFormData] = useState({
    title: '',
    imgSrc: '',
    order_num: 0,
    subject_id: id
  })
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [isSubmitLoading, setIsSubmitLoading] = useState(false)

  const handleFormChange = (key: string, value: string | number) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value
    }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      // 실제 업로드 시에는 이미지 URL을 받아서 imgSrc에 설정해야 합니다
      // 여기서는 임시로 파일명만 표시
      handleFormChange('imgSrc', file.name)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitLoading(true)

    try {
      const supabase = createClient()
      if (!imageFile) {
        throw new Error('이미지가 없습니다.')
      }
      const imageUrl = await uploadImage(supabase, imageFile)
      const data = { ...formData, imgSrc: imageUrl }

      insertDataToTable(supabase, 'subject_subcategories', {
        title: formData.title,
        imgSrc: imageUrl,
        order_num: formData.order_num,
        subject_id: id
      })

      handleClose()
    } catch (error) {
      console.error('Error:', error)
    } finally {
      setIsSubmitLoading(false)
    }
  }

  return (
    <Card className='w-full mx-auto border-none shadow-none'>
      <CardContent>
        <form onSubmit={handleSubmit} className='space-y-6 pt-6'>
          <div className='space-y-2'>
            <Label htmlFor='title' className='text-lg'>
              제목
            </Label>
            <Input
              id='title'
              placeholder='제목을 입력하세요'
              value={formData.title}
              onChange={(e) => handleFormChange('title', e.target.value)}
              className='h-12'
            />
          </div>

          <div className='space-y-2'>
            <Label className='text-lg'>이미지</Label>
            <div className='border-2 border-dashed rounded-lg p-8 bg-gray-50'>
              <Input
                type='file'
                accept='image/*'
                onChange={handleImageChange}
                className='hidden'
                id='image-upload'
              />
              <Label
                htmlFor='image-upload'
                className='flex flex-col items-center cursor-pointer'
              >
                <Upload className='w-12 h-12 mb-2 text-gray-400' />
                <span>
                  {imageFile
                    ? imageFile.name
                    : '이미지를 선택하거나 드래그하세요'}
                </span>
              </Label>
            </div>
          </div>

          <div className='space-y-2'>
            <Label htmlFor='order_num' className='text-lg'>
              순서
            </Label>
            <Input
              id='order_num'
              type='text'
              placeholder='순서를 입력하세요'
              value={formData.order_num}
              onChange={(e) =>
                handleFormChange('order_num', parseInt(e.target.value) || 0)
              }
              className='h-12'
            />
          </div>

          <div className='flex gap-2 pt-4'>
            <Button
              type='button'
              variant='outline'
              onClick={handleClose}
              className='flex-1 h-12'
            >
              취소
            </Button>
            <Button
              type='submit'
              className='flex-1 h-12'
              disabled={isSubmitLoading}
            >
              {isSubmitLoading ? '저장 중...' : '저장'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
