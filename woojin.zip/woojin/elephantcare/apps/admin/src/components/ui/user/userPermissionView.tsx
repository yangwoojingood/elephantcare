'use client'

import { PencilIcon } from 'lucide-react'

import { Button } from '@packages/ui/components/button'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle
} from '@packages/ui/components/card'
import { Checkbox } from '@packages/ui/components/checkbox'
import { Label } from '@packages/ui/components/label'

export interface Permission {
  id: string
  title: string
}

interface UserDetail {
  id: string
  name: string
  email: string
  role: string
  permissions: string[]
}

interface UserPermissionsViewProps {
  subjects?: Permission[]
  userDetail: UserDetail
  onPermissionChange?: (permissionId: string, checked: boolean) => void
}

export function UserPermissionsView({
  subjects = [],
  userDetail,
  onPermissionChange
}: UserPermissionsViewProps) {
  return (
    <div className='max-w-4xl mx-auto p-6 space-y-6 overflow-y-auto max-h-[]'>
      {/* User Info Card */}
      <Card>
        <CardHeader className='pb-4'>
          <CardTitle>사용자 정보</CardTitle>
        </CardHeader>
        <CardContent>
          <div className='flex items-center space-x-4'>
            <div className='space-y-1'>
              <h3 className='text-xl font-medium'>{userDetail.name}</h3>
              <p className='text-sm text-gray-500'>{userDetail.email}</p>
              <div className='flex items-center space-x-2'>
                <span className='text-sm text-gray-500'>역할:</span>
                <span className='bg-primary/10 text-primary rounded-full px-2 py-0.5 text-sm'>
                  {userDetail.role}
                </span>
                <span className='text-xs text-gray-500'>
                  * 수정하고싶으면 supabase 에서 수정해주세요
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Permissions Card */}
      <Card className='flex flex-col max-h-96 overflow-y-auto'>
        <CardHeader className='pb-4'>
          <CardTitle>권한 관리</CardTitle>
        </CardHeader>
        <CardContent className='flex flex-col'>
          <div className='grid grid-cols-2 md:grid-cols-2 gap-4'>
            {subjects.map((subject) => (
              <div
                key={subject.id}
                className='flex items-start space-x-3 p-3 rounded-lg border'
              >
                <Checkbox
                  id={subject.id}
                  checked={userDetail.permissions?.includes(subject.id)}
                  onCheckedChange={(checked) =>
                    onPermissionChange?.(subject.id, checked as boolean)
                  }
                  className='mt-1'
                />
                <div className='space-y-1'>
                  <Label
                    htmlFor={subject.id}
                    className='text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70'
                  >
                    {subject.title}
                  </Label>{' '}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
