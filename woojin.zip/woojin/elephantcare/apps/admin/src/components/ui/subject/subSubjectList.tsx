'use client'

import { ModalPortal } from '@/components/common'
import { SubClass } from '@/types'
import { PlusIcon } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { useEffect } from 'react'

import { createClient } from '@packages/supabase/utils/client'
import { Button } from '@packages/ui/components/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@packages/ui/components/table'

import { SubjectSubForm } from './subjectSubForm'

export function SubClassList({ id }: { id: string }) {
  const [subClasses, setSubClasses] = useState<SubClass[]>([])
  const [isOpen, setIsOpen] = useState(false)
  useEffect(() => {
    const fetchSubClasses = async () => {
      const supabase = await createClient()
      const { data, error } = await supabase
        .from('subject_subcategories')
        .select('*')
        .eq('subject_id', id || '')
        .order('order_num', { ascending: true })
      if (error) {
        console.error('Error:', error)
      }
      setSubClasses(data || [])
    }
    fetchSubClasses()
  }, [id])
  const router = useRouter()
  const handleClassClick = (id: string) => {
    router.push(`/main/subject/list/${id}/sub`)
  }
  return (
    <div>
      <ModalPortal isOpen={isOpen} handleClose={() => setIsOpen(false)}>
        <div>투 뎁스 추가</div>
        <SubjectSubForm id={id} handleClose={() => setIsOpen(false)} />
      </ModalPortal>
      <Button
        onClick={() => {
          setIsOpen(true)
        }}
        variant='outline'
        className='float-right flex items-center gap-2'
      >
        <PlusIcon className='w-4 h-4' />
        추가하기
      </Button>
      {subClasses.length === 0 ? (
        <div>투뎁스 카테고리가 없습니다.</div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>img</TableHead>
              <TableHead>Order Number</TableHead>
              <TableHead>actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {subClasses.map((v) => (
              <TableRow
                onClick={() => handleClassClick(v.id)}
                key={v.id}
                className='cursor-pointer'
              >
                <TableCell>{v.title || ''}</TableCell>
                <TableCell>{v.imgSrc || ''}</TableCell>
                <TableCell>{v.order_num || ''}</TableCell>
                <TableCell>...</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  )
}
