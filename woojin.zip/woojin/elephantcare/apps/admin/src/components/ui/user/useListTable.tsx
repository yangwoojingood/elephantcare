'use client'

import { ModalPortal } from '@/components/common'
import { useUserList } from '@/hooks/useUserList'
import { deleteUser } from '@/services/user.service'
import { User } from '@/types'
import { EllipsisIcon } from 'lucide-react'
import { useEffect, useState } from 'react'

import { selectData } from '@packages/supabase/database/select'
import { createClient } from '@packages/supabase/utils/client'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@packages/ui/components/dropdown-menu'
import { Spinner } from '@packages/ui/components/spinner'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@packages/ui/components/table'

import { Permission, UserPermissionsView } from './userPermissionView'

export function UserListTable() {
  const { userList, isLoading } = useUserList()
  const [selectedUser, setSelectedUser] = useState<User | null>(null)

  const [isOpen, setIsOpen] = useState(false)
  if (isLoading)
    return (
      <div>
        <Spinner />
      </div>
    )
  const handleDeleteUser = async (id: string) => {
    try {
      await deleteUser(id)
    } catch (error) {
      console.error(error)
    }
  }
  const handleOpen = (user: User) => {
    setIsOpen(true)
    setSelectedUser(user)
  }
  const handleClose = () => {
    setIsOpen(false)
  }
  return (
    <div>
      <p className='text-sm mt-4 text-gray-500 font-semibold'>
        전체 사용자 <span className='text-blue-500'>{userList.length}</span>명
      </p>
      <Table className='mt-4 overflow-y-auto max-h-[calc(100vh-4rem-2.5rem)] whitespace-nowrap h-full px-4'>
        <TableHeader>
          <TableRow className='bg-gray-100'>
            <TableHead className='max-w-32 overflow-hidden text-ellipsis'>
              id
            </TableHead>
            <TableHead>이름</TableHead>
            <TableHead>EMAIL</TableHead>
            <TableHead>기타 정보</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className='overflow-y-auto max-h-[calc(100vh-4rem-2.5rem)] h-full'>
          {userList.map((user) => (
            <TableRow key={user.id} className='h-12'>
              <TableCell className='max-w-32 overflow-hidden text-ellipsis'>
                {user.id}
              </TableCell>
              <TableCell>{user.name || 'null'}</TableCell>
              <TableCell>{user.email || 'null'}</TableCell>
              <TableCell>
                <p
                  className='text-sky-500 cursor-pointer'
                  onClick={() => handleOpen(user)}
                >
                  권한 관리
                </p>
              </TableCell>
              {/* 유저 삭제는 supabase에서
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger>
                    <EllipsisIcon className='h-4' />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className='rounded-lg'>
                    <DropdownMenuItem className='flex justify-center w-full h-full cursor-pointer'>
                      <p
                        className='text-gray-500 cursor-pointer'
                        onClick={() => handleOpen(user)}
                      >
                        계정 상세보기
                      </p>
                    </DropdownMenuItem>
                    <DropdownMenuItem className='flex justify-center w-full h-full cursor-pointer'>
                      <p
                        className='text-red-500'
                        onClick={() => handleDeleteUser(user.id)}
                      >
                        삭제
                      </p>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell> */}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <ModalPortal isOpen={isOpen} handleClose={handleClose}>
        <h1>프로그램 관리</h1>
        <PermissionModal id={selectedUser?.id || ''} />
      </ModalPortal>
    </div>
  )
}

export function PermissionModal({ id }: { id: string }) {
  const [userDetail, setUserDetail] = useState<User | null>(null)
  const [subjects, setSubjects] = useState<Permission[]>([])
  const fetchUserDetail = async () => {
    try {
      const supabase = createClient()
      const data = await selectData<User>({
        supabase,
        table: 'User',
        column: 'id',
        id
      })
      const { data: fetchedSubjects } = await supabase
        .from('subjects')
        .select('id, title')
      setSubjects(fetchedSubjects || [])
      setUserDetail(data)
    } catch (error) {
      console.error(error)
    }
  }

  async function searchPermission(title: string) {
    const supabase = createClient()
    const { data } = await supabase
      .from('subjects')
      .select('id, title')
      .like('title', `%${title}%`)
    return data
  }

  // updatePermission 함수로 supabase 업데이트 및 상태 업데이트 로직 분리
  async function updatePermission(permissionId: string, checked: boolean) {
    try {
      const supabase = createClient()
      if (!userDetail) return

      const currentPermissions: string[] = userDetail.permissions || []
      let updatedPermissions: string[]

      if (!checked) {
        // 체크 해제 시: permissionId 제거
        updatedPermissions = currentPermissions.filter(
          (id) => id !== permissionId
        )
      } else {
        // 체크 시: 중복 방지 후 추가
        if (currentPermissions.includes(permissionId)) return
        updatedPermissions = [...currentPermissions, permissionId]
      }

      // supabase의 User 테이블 업데이트
      const { error } = await supabase
        .from('User')
        .update({ permissions: updatedPermissions })
        .eq('id', userDetail.id)

      if (error) {
        console.error('Error updating user permissions:', error)
        return
      }
      // supabase 업데이트 성공 시, local state 업데이트
      fetchUserDetail()
    } catch (error) {
      console.error(error)
    }
  }

  useEffect(() => {
    fetchUserDetail()
  }, [])

  return (
    <div>
      {userDetail && (
        <UserPermissionsView
          subjects={subjects}
          userDetail={userDetail}
          onPermissionChange={(permissionId, checked) => {
            // 권한 변경 처리 로직
            updatePermission(permissionId, checked)
          }}
        />
      )}
    </div>
  )
}
