'use client'

import { ModalPortal } from '@/components/common'
import { Class } from '@/types'
import { PlusIcon } from 'lucide-react'
import { EllipsisIcon } from 'lucide-react'
import { useEffect, useState } from 'react'

import { useClass } from '@hooks'

import { createClient } from '@packages/supabase/utils/client'
import { Button } from '@packages/ui/components/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@packages/ui/components/dropdown-menu'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@packages/ui/components/table'

import { ClassUpdateForm } from './claaUpdateFrom'
import { ClassAddForm } from './classAddForm'

interface ClassInitialProps {
  classId: string
  title: string
  url: string
  extra_url?: string
  order_num: number
  handout: string
}

export function ClassList({ id, isSub }: { id: string; isSub: boolean }) {
  const [classes, setClasses] = useState<Class[]>([])
  const { handleDeleteClass } = useClass()
  const [selectedClass, setSelectedClass] = useState<ClassInitialProps>({
    classId: '',
    title: '',
    url: '',
    order_num: 0,
    handout: ''
  })
  const [showUpdateForm, setShowUpdateForm] = useState(false)
  useEffect(() => {
    const fetchClasses = async () => {
      const supabase = await createClient()
      const { data, error } = await supabase
        .from('classes')
        .select('*')
        .or(`subject_id.eq.${id},category_id.eq.${id}`)
        .order('order_num', { ascending: true })

      if (error) {
        console.error('Error fetching classes:', error)
      }
      setClasses(data || [])
    }
    fetchClasses()
  }, [id])
  const handleDelete = (id: string) => {
    const a = confirm('정말 수업을 삭제하시겠습니까?')
    if (a) {
      handleDeleteClass(id)
    }
  }
  const [isOpen, setIsOpen] = useState(false)
  const handleAddClass = () => {
    setIsOpen(true)
  }
  const handleClose = () => {
    setIsOpen(false)
  }
  const handleShowUpdate = (classItem: Class) => {
    const prop = {
      classId: classItem.id,
      title: classItem.title,
      url: classItem.url,
      extra_url: classItem.extra_url,
      order_num: classItem.order_num,
      handout: classItem.handout as string
    }
    setSelectedClass(prop)
    setShowUpdateForm(true)
  }

  const handleUpdateClose = () => {
    setShowUpdateForm(false)
  }
  return (
    <div>
      <ModalPortal isOpen={isOpen} handleClose={handleClose}>
        <div>Class 추가</div>
        <ClassAddForm id={id} handleClose={handleClose} isSub={isSub} />
      </ModalPortal>
      <ModalPortal isOpen={showUpdateForm} handleClose={handleUpdateClose}>
        <div>Class 추가</div>
        <ClassUpdateForm
          parentId={id}
          handleClose={handleUpdateClose}
          isSub={isSub}
          initialData={selectedClass}
        />
      </ModalPortal>
      <Button
        onClick={handleAddClass}
        variant='outline'
        className='float-right flex items-center gap-2'
      >
        <PlusIcon />
        추가
      </Button>
      <Table className='whitespace-nowrap mt-4'>
        <TableHeader className='bg-gray-100'>
          <TableRow>
            {/* <TableHead>id</TableHead> */}
            <TableHead>제목</TableHead>
            <TableHead className='max-w-60 overflow-hidden text-ellipsis'>
              url
            </TableHead>
            <TableHead>order_num</TableHead>
            <TableHead>학습지</TableHead>
            <TableHead>상세 보기</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {classes.map((v) => (
            <TableRow key={v.id}>
              {/* <TableCell>{v.id}</TableCell> */}
              <TableCell>{v.title}</TableCell>
              <TableCell className='max-w-60 overflow-hidden text-ellipsis'>
                {v.url}
              </TableCell>
              <TableCell>{v.order_num}</TableCell>
              <TableCell>{v.handout}</TableCell>
              <TableCell>
                <p
                  className='text-gray-500 cursor-pointer'
                  onClick={() => {
                    handleShowUpdate(v)
                  }}
                >
                  상세 보기
                </p>
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger>
                    <EllipsisIcon className='h-4' />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className='rounded-lg'>
                    <DropdownMenuItem className='flex justify-center w-full h-full cursor-pointer'>
                      <p
                        className='text-red-500'
                        onClick={() => {
                          handleDelete(v.id)
                        }}
                      >
                        삭제
                      </p>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
