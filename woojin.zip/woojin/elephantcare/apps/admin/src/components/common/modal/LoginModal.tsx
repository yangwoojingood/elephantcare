'use client'

import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { toast } from 'react-toastify'

import { CheckButton, CheckInput } from '@packages/ui/components/check'

function LoginForm() {
  const router = useRouter()
  const handleLoginSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    try {
      e.preventDefault()
      const formData = new FormData(e.target as HTMLFormElement)
      const email = formData.get('email')
      const password = formData.get('password')
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      })
      // 에러 메시지 확인
      const encodedError = response.headers.get('X-Error-Message')
      const errorMessage = encodedError
        ? Buffer.from(encodedError, 'base64').toString()
        : '권한이 없습니다.'

      if (response.status === 302) {
        toast.error(errorMessage)
        return
      }

      if (response.ok) {
        toast.success('로그인 성공')
        router.push('/main')
      }
    } catch (error) {
      toast.error('로그인 중 오류가 발생했습니다.')
    }
  }

  return (
    <div className='flex flex-col justify-start items-center h-full w-full p-4 text-lg text-deactivate font-bold'>
      <div className='flex flex-col items-center gap-8 mb-4'>
        <Image
          src='/assets/images/logo.png'
          alt='Logo'
          width={149}
          height={82}
        />
        <h1 className='text-xl text-black font-bold text-center'>
          위인과 함께하는 코끼리 탐구 살롱 어드민
          <br />
          로그인
        </h1>
      </div>
      <form
        onSubmit={(e) => handleLoginSubmit(e)}
        className='w-full flex flex-col py-4 gap-2'
      >
        <CheckInput type='email' name='email' placeholder='이메일' />
        <CheckInput type='password' name='password' placeholder='비밀번호' />
        <div className='mt-2 space-y-2'>
          <CheckButton type='submit' variant='filled' size='lg'>
            로그인
          </CheckButton>
          <CheckButton variant='outlined' size='lg'>
            회원가입
          </CheckButton>
        </div>
      </form>
      <div className='flex text-base justify-center gap-4 text-deactivate'>
        <button>아이디 찾기</button>ㅣ<button>비밀번호 찾기</button>
      </div>
    </div>
  )
}

export { LoginForm }
