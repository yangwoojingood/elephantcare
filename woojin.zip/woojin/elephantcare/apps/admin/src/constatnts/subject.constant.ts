import { ClassCategoriesType, GradeCategoriesType } from '@/types'

const grades: GradeCategoriesType[] = [
  '1학년',
  '2학년',
  '3학년',
  '4학년',
  '5학년',
  '6학년'
]

const classes: ClassCategoriesType[] = ['늘봄', '방과후']

export { grades, classes }
