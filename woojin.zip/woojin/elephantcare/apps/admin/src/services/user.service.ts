import { User } from '@types'

import { selectDataFromTable } from '@packages/supabase/database/select'
import { createClient } from '@packages/supabase/utils/client'

export const fetchUsers = async () => {
  const supabase = createClient()
  const data = await selectDataFromTable<User[]>(supabase, 'User')
  return data
}

export const deleteUser = async (id: string) => {
  const supabase = createClient()
  const data = await supabase.auth.admin.deleteUser(id)
  return data
}
