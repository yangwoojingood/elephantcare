import { Class } from '@/types/class.type'

import { selectDataFromTable } from '@packages/supabase/database/select'
import { createClient } from '@packages/supabase/utils/client'

const fetchClass = async () => {
  const supabase = createClient()
  const data = await supabase.from('classes').select('*')
  return data
}
const deleteClass = async (id: string) => {
  const supabase = createClient()
  // 해당 class를 가져옵니다.
  const classItem = await supabase
    .from('classes')
    .select()
    .eq('id', id)
    .single()
  // 해당 class의 handout을 삭제합니다
  if (classItem.data?.handout) {
    const { error } = await supabase.storage
      .from('programs')
      .remove([classItem.data.handout])
    if (error) {
      return Error('Error deleting handout')
    }
  }
  // 해당 class를 삭제합니다.
  const { data, error } = await supabase.from('classes').delete().eq('id', id)
  if (error) {
    return Error('Error deleting handout')
  }
  return data
}
export { fetchClass, deleteClass }
