import { SubjectType } from '@/types/subject.type'

import { deleteDataFromTable } from '@packages/supabase/database/delete'
import { selectDataFromTable } from '@packages/supabase/database/select'
import { createClient } from '@packages/supabase/utils/client'

import { deleteClass } from './class.service'

const fetchSubjects = async () => {
  const supabase = createClient()
  const data = await selectDataFromTable<SubjectType[]>(supabase, 'subjects')
  return data
}

const deleteSubject = async (id: string) => {
  const supabase = createClient()
  // subject를 가져옵니다
  const subject = await supabase
    .from('subjects')
    .select('*')
    .eq('id', id)
    .single()
  if (!subject) {
    throw new Error('Subject not found')
  }
  // 해당 subject의 class들을 가져와서 삭제합니다.
  const { data: classIDs, error: classError } = await supabase
    .from('classes')
    .select('id')
    .eq('subject_id', id)

  if (classError) {
    console.error('Error fetching class IDs:', classError)
    return
  }

  if (classIDs && classIDs.length > 0) {
    await Promise.all(classIDs.map((classItem) => deleteClass(classItem.id)))
  }

  // 해당 subject의 syllabus와 thumnail을 삭제합니다.
  if (subject.data?.syllabus) {
    const { error } = await supabase.storage
      .from('programs')
      .remove([subject.data.syllabus])
    if (error) {
      return Error('Error deleting syllabus')
    }
  }

  if (subject.data?.imgSrc) {
    const { error } = await supabase.storage
      .from('programs')
      .remove([subject.data.imgSrc])
    if (error) {
      return Error('Error deleting thumbnail')
    }
  }

  // 해당 subject를 삭제합니다
  const { data, error } = await supabase.from('subjects').delete().eq('id', id)

  if (error) {
    console.error('Error deleting classes:', error)
    return
  }
  return data
}
export { fetchSubjects, deleteSubject }
