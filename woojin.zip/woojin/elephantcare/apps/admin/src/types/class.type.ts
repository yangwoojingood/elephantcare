interface Class {
  id: string
  title: string
  url: string
  extra_url?: string
  order_num: number
  handout: string | null
}

interface SubClass {
  id: string
  title: string
  imgSrc: string
  order_num: number
}

export type { Class, SubClass }
