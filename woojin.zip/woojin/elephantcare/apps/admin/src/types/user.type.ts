type Roles = 'admin' | 'user'
interface User {
  id: string
  name: string
  email: string
  emailVerified: string
  updatedAt: string
  createdAt: string
  permissions: string[]
  role: Roles
}
export type { User }
