import { fetchUsers } from '@/services/user.service'
import { useState } from 'react'
import { useEffect } from 'react'

import { User } from '@types'

export function useUserList() {
  const [userList, setUserList] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(false)
  useEffect(() => {
    const fetchSubjects = async () => {
      try {
        setIsLoading(true)
        const data = await fetchUsers()
        if (data) {
          setUserList(data)
        }
      } catch (error) {
        console.error('Error fetching Users:', error)
      } finally {
        setIsLoading(false)
      }
    }
    fetchSubjects()
  }, [])

  return { userList, isLoading }
}
