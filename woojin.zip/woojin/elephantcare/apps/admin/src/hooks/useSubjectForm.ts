import { FormData } from '@/types'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { toast } from 'react-toastify'

import { insertDataToTable } from '@packages/supabase/database/insert'
import { uploadFile, uploadImage } from '@packages/supabase/storage/upload'
import { createClient } from '@packages/supabase/utils/client'

export function useSubjectForm() {
  const router = useRouter()
  const [formData, setFormData] = useState<FormData>({
    title: '',
    grade: [],
    image: null,
    class: [],
    theme: [''],
    syllabusFile: null,
    isTwoDepth: false
  })

  const [isSubmitLoading, setIsSubmitLoading] = useState(false)

  const handleFormChange = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleArrayChange = (
    field: 'class' | 'theme',
    value: string,
    index: number
  ) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].map((item, i) => (i === index ? value : item))
    }))
  }

  const handleArrayAdd = (field: 'class' | 'theme') => {
    setFormData((prev) => ({
      ...prev,
      [field]: [...prev[field], '']
    }))
  }

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    fileType: 'image' | 'syllabusFile'
  ) => {
    if (e.target.files?.[0]) {
      handleFormChange(fileType, e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitLoading(true)

    try {
      const supabase = createClient()
      let imgSrc = ''
      if (formData.image) {
        imgSrc = await uploadImage(supabase, formData.image)
      }

      let syllabus = ''
      if (formData.syllabusFile) {
        syllabus = await uploadFile(supabase, 'syllabus', formData.syllabusFile)
      }

      await insertDataToTable(supabase, 'subjects', {
        title: formData.title,
        imgSrc,
        grade: formData.grade,
        class: formData.class,
        theme: formData.theme,
        syllabus: syllabus
      })
      toast.success('과목 생성 완료')
      router.push('/main/subject/list')
    } catch (error) {
      console.error(error)
      toast.error('과목 생성 실패')
    } finally {
      setIsSubmitLoading(false)
    }
  }

  return {
    formData,
    handleFormChange,
    isSubmitLoading,
    handleArrayChange,
    handleArrayAdd,
    handleFileChange,
    handleSubmit
  }
}
