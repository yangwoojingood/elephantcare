// middleware.ts
import { type NextRequest, NextResponse } from 'next/server'

import { createClient } from '@packages/supabase/utils/server'

// // 각 경로별 필요한 권한 정의
// const PERMISSION_ROUTES = {
//   shapes: 'shapes',
//   empathy: 'empathy',
//   sapiens: 'sapiens',
//   artnspeech: 'artnspeech'
// } as const

export async function middleware(request: NextRequest) {
  const response = NextResponse.next({
    request: {
      headers: request.headers
    }
  })

  const supabase = await createClient()
  const {
    data: { user }
  } = await supabase.auth.getUser()

  const { data: userRole } = await supabase
    .from('User')
    .select('role')
    .eq('email', user?.email)
    .single()

  // auth api 는 로그인 상태 상관없이 접근 가능
  if (request.nextUrl.pathname.startsWith('/api/auth')) {
    return response
  }
  if (request.nextUrl.pathname === '/') {
    return response
  }
  if (userRole?.role === 'admin' && request.nextUrl.pathname === '/') {
    const redirectUrl = new URL('/main', request.url)
    return NextResponse.redirect(redirectUrl)
  }

  if (userRole?.role === 'user') {
    const errorMessage = Buffer.from('어드민이 아닙니다.').toString('base64')
    const response = NextResponse.redirect(new URL('/', request.url), {
      status: 302
    })
    response.headers.set('X-Error-Message', errorMessage)
    return response
  }

  if (userRole?.role === 'user') {
    return NextResponse.json({ error: '어드민이 아닙니다.' }, { status: 302 })
  }
  if (userRole?.role !== 'admin' && request.nextUrl.pathname !== '/') {
    const redirectUrl = new URL('/', request.url)
    return NextResponse.redirect(redirectUrl, 302)
  }

  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'
  ]
}
