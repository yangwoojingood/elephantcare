/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true
  },
  eslint: {
    ignoreDuringBuilds: true
  },
  // React 18 관련 설정
  reactStrictMode: true,
  // 실험적 기능 활성화 (turbopack 사용중이므로)
  experimental: {
    turbo: true
  },
  transpilePackages: [
    '@packages/ui',
    '@packages/eslint-config',
    '@packages/typescript-config'
  ],
  output: 'standalone',
  distDir: '.next'
}

export default nextConfig
