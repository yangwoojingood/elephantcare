
## 실행법 
pnpm이 없다면 -> 

npm install -g pnpm 

of

brew install pnpm


```bash
pnpm run web:dev
```

### 변경점: 폰트 woff2 + variable으로, icons svg로 변경, 반응형 추가, src 폴더 구조 사용, 모노레포로 변경, Mui 삭제, shadcn ui 사용 고민중

### 추가 구현: main페이지, 로그인 모달, 마이페이지 드롭다운, programs 디바운스 검색

### .env 이전이랑 똑같이, web폴더 루트에 위치
#### canvas와 auth 리팩토링은 코드 이해를 좀 더 하고 하겠습니다.. flow 시각화도 같이

## pnpm turborepo 모노레포 구조입니다.

### Next.js 14, TailwindCSS, zustand, @tanstack/react-query 사용 예정. ui는 일단 shadcn인데 쓸지 안쓸지는 모르겠습니다.
